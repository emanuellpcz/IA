import Link from 'next/link';
import { Bike, AlarmClock, CreditCard, Utensils, Star, Car } from 'lucide-react';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { TileStrip } from '@/components/TileStrip';
import { SectionTitle } from '@/components/SectionTitle';
import { CategoryCard } from '@/components/CategoryCard';
import { WhatsAppButton } from '@/components/WhatsAppButton';
import { categories } from '@/lib/menu';

const services = [
  { icon: CreditCard, title: 'Múltiples medios de pago' },
  { icon: Utensils, title: 'Menú adaptado' },
  { icon: Star, title: 'Exclusividad' },
  { icon: Car, title: 'Estacionamiento' },
];

export default function Home() {
  return (
    <>
      <Header />
      <main>
        {/* Hero */}
        <section
          id="inicio"
          className="relative flex min-h-[90vh] items-center justify-center overflow-hidden"
        >
          <img
            src="https://images.pexels.com/photos/12983263/pexels-photo-12983263.jpeg?auto=compress&cs=tinysrgb&h=1200&w=1920"
            alt="Mesa mexicana tradicional con platillos típicos en cerámica colorida"
            width={1920}
            height={1200}
            className="absolute inset-0 h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-rich-mahogany-950/70 via-rich-mahogany-950/60 to-rich-mahogany-950/70" />
          <div className="relative z-10 mx-auto max-w-3xl px-4 text-center animate-hero-fade motion-reduce:animate-none">
            <p className="mb-4 text-sm font-semibold uppercase tracking-wider text-cream/90">
              Tradición que nos reúne
            </p>
            <h1
              className="font-serif font-bold leading-[1.05] text-cream text-balance"
              style={{ fontSize: 'clamp(2.75rem, 7vw, 5.5rem)' }}
            >
              El sabor de México se siente como en casa
            </h1>
            <p className="mx-auto mt-5 max-w-xl text-lg text-cream/85 sm:text-xl">
              Tradición, sabor y momentos para compartir
            </p>
            <div className="mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row">
              <WhatsAppButton
                variant="primary"
                message="reserve"
                label="Reservar mesa"
                size="lg"
              />
              <Link
                href="#menu"
                className="inline-flex h-14 items-center justify-center rounded-full border-[1.5px] border-cream px-8 text-base font-semibold text-cream transition-colors hover:bg-cream/10 focus-ring"
              >
                Ver la carta
              </Link>
            </div>
          </div>
          <div className="absolute bottom-0 left-0 right-0 z-10">
            <TileStrip />
          </div>
        </section>

        {/* Franja Club Comal */}
        <section id="membresia-inicio" className="bg-rich-mahogany-600 text-cream">
          <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-6 px-4 py-10 sm:px-6 md:flex-row lg:px-8">
            <div className="max-w-2xl text-center md:text-left">
              <h2
                className="font-serif font-bold leading-tight text-cream"
                style={{ fontSize: 'clamp(1.5rem, 3vw, 2.25rem)' }}
              >
                Conviértete en parte de nuestra familia y disfruta varios beneficios
              </h2>
              <p className="mt-3 flex flex-wrap items-center justify-center gap-x-3 gap-y-1 text-sm text-cream/85 md:justify-start">
                <span>Postre de cortesía en tu cumpleaños</span>
                <span className="hidden h-3 w-px bg-cream/40 sm:inline-block" />
                <span>10 % de descuento en tus domicilios</span>
                <span className="hidden h-3 w-px bg-cream/40 sm:inline-block" />
                <span>Acceso anticipado a eventos y menús de temporada</span>
              </p>
            </div>
            <WhatsAppButton
              variant="primary"
              message="club"
              label="Únete ahora"
              size="lg"
              className="shrink-0"
            />
          </div>
        </section>

        {/* Descubre nuestros sabores */}
        <section id="menu" className="bg-white py-20 sm:py-28">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <SectionTitle
              title="Descubre nuestros sabores"
              subtitle="Explora nuestras diferentes categorías"
            />
            <div className="mt-14 grid grid-cols-1 gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-4">
              {categories.map((cat) => (
                <CategoryCard key={cat.slug} category={cat} />
              ))}
            </div>
          </div>
        </section>

        {/* Disfruta México donde estés */}
        <section id="nosotros" className="bg-white pb-20 sm:pb-28">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <SectionTitle title="Disfruta México donde estés" />
            <p className="mx-auto mt-5 max-w-2xl text-center text-lg leading-relaxed text-rich-mahogany-700/80">
              En tu mesa o en la de tu casa, la receta es la misma: maíz recién
              molido, brasa y tiempo para la sobremesa.
            </p>
            <div className="mt-12 overflow-hidden rounded-[4px]">
              <img
                src="https://images.pexels.com/photos/7613441/pexels-photo-7613441.jpeg?auto=compress&cs=tinysrgb&h=700&w=1470"
                alt="Manos colocando una tortilla en un comal de barro tradicional"
                width={1470}
                height={700}
                className="h-full w-full object-cover"
              />
            </div>
            <div className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-2">
              {/* Domicilios */}
              <div className="flex flex-col items-center rounded-[4px] border border-champagne-mist-300/50 p-8 text-center">
                <Bike className="h-8 w-8 text-rich-mahogany-600" strokeWidth={1.5} />
                <h3 className="mt-4 font-serif text-xl font-semibold text-rich-mahogany-950">
                  Domicilios
                </h3>
                <p className="mt-2 text-base text-rich-mahogany-700/80">
                  Realiza tu pedido
                </p>
                <div className="mt-6">
                  <WhatsAppButton variant="primary" message="delivery" label="Pedir a domicilio" />
                </div>
              </div>
              {/* Reservas */}
              <div className="flex flex-col items-center rounded-[4px] border border-champagne-mist-300/50 p-8 text-center">
                <AlarmClock className="h-8 w-8 text-rich-mahogany-600" strokeWidth={1.5} />
                <h3 className="mt-4 font-serif text-xl font-semibold text-rich-mahogany-950">
                  Reservas
                </h3>
                <p className="mt-2 text-base text-rich-mahogany-700/80">
                  Reserva tu mesa
                </p>
                <div className="mt-6 flex flex-col items-center gap-3">
                  <WhatsAppButton variant="primary" message="reserve" label="Reservar mesa" />
                  <Link
                    href="/reservas"
                    className="text-sm font-medium text-rich-mahogany-600 underline underline-offset-[0.25em] hover:text-rich-mahogany-700"
                  >
                    Más información
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Servicios */}
        <section className="border-y border-rich-mahogany-100 bg-white py-16">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <SectionTitle title="Servicios" />
            <div className="mt-12 grid grid-cols-2 gap-y-10 md:grid-cols-4 md:divide-x md:divide-rich-mahogany-100">
              {services.map(({ icon: Icon, title }) => (
                <div
                  key={title}
                  className="flex flex-col items-center px-4 text-center"
                >
                  <Icon
                    className="h-8 w-8 text-black-forest-700"
                    strokeWidth={1.5}
                  />
                  <h3 className="mt-3 font-sans text-base font-bold text-rich-mahogany-700">
                    {title}
                  </h3>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
