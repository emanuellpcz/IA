import './globals.css';
import type { Metadata } from 'next';
import { Cormorant_Garamond, Plus_Jakarta_Sans } from 'next/font/google';

const cormorant = Cormorant_Garamond({
  subsets: ['latin'],
  weight: ['600', '700'],
  style: ['normal', 'italic'],
  variable: '--font-cormorant',
  display: 'swap',
});

const jakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700'],
  variable: '--font-jakarta',
  display: 'swap',
});

export const metadata: Metadata = {
  metadataBase: new URL('https://comaldecasa.co'),
  title: 'Comal de Casa | Tradición que nos reúne',
  description:
    'Cocina mexicana tradicional: tortillas hechas a diario, salsas de molcajete y guisos de cocción lenta. Reserva tu mesa o pide a domicilio.',
  keywords: [
    'comida mexicana',
    'restaurante mexicano',
    'tacos',
    'mole',
    'comida tradicional',
    'Comal de Casa',
  ],
  openGraph: {
    title: 'Comal de Casa | Tradición que nos reúne',
    description:
      'Cocina mexicana tradicional: tortillas hechas a diario, salsas de molcajete y guisos de cocción lenta.',
    type: 'website',
    locale: 'es_CO',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="es-CO" className={`${cormorant.variable} ${jakarta.variable}`}>
      <body className="font-sans">{children}</body>
    </html>
  );
}
