import type { Metadata } from 'next';
import { Clock, MapPin, Users } from 'lucide-react';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { SectionTitle } from '@/components/SectionTitle';
import { FaqAccordion } from '@/components/FaqAccordion';
import { WhatsAppButton } from '@/components/WhatsAppButton';
import { business } from '@/lib/business';

export const metadata: Metadata = {
  title: 'Reservas | Comal de Casa',
  description:
    'Reserva tu mesa en Comal de Casa por WhatsApp. Te confirmamos fecha, hora y número de personas.',
};

const steps = [
  'Escríbenos por WhatsApp.',
  'Cuéntanos la fecha, la hora y cuántas personas son.',
  'Te confirmamos tu mesa.',
];

const faqs = [
  {
    question: '¿Es necesario reservar?',
    answer:
      'No es obligatorio, pero lo recomendamos los fines de semana para asegurarte tu mesa.',
  },
  {
    question: '¿Cuánto tiempo guardan la mesa?',
    answer: 'Tenemos 15 minutos de tolerancia después de la hora reservada.',
  },
  {
    question: '¿Tienen opciones vegetarianas?',
    answer:
      'Sí, los platos vegetarianos están marcados con una etiqueta verde en la carta.',
  },
  {
    question: '¿Reciben niños?',
    answer: 'Sí, las familias son siempre bienvenidas en Comal de Casa.',
  },
  {
    question: '¿Hay parqueadero?',
    answer: 'Sí, contamos con estacionamiento para nuestros visitantes.',
  },
];

export default function ReservasPage() {
  return (
    <>
      <Header />
      <main>
        {/* Hero compacto */}
        <section className="relative flex min-h-[55vh] items-end overflow-hidden">
          <img
            src="https://images.pexels.com/photos/13676679/pexels-photo-13676679.jpeg?auto=compress&cs=tinysrgb&h=800&w=1400"
            alt="Mesa puesta con cazuelas de barro, flores y velas"
            width={1400}
            height={800}
            className="absolute inset-0 h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-rich-mahogany-950/55 via-rich-mahogany-950/55 to-rich-mahogany-950/70" />
          <div className="relative z-10 mx-auto w-full max-w-7xl px-4 pb-12 sm:px-6 lg:px-8">
            <h1
              className="font-serif font-bold leading-[1.05] text-cream"
              style={{ fontSize: 'clamp(2.25rem, 5vw, 4rem)' }}
            >
              Reserva tu mesa
            </h1>
            <p className="mt-3 max-w-xl text-lg text-cream/85">
              Pásale, que la mesa ya está servida
            </p>
          </div>
        </section>

        {/* CTA principal */}
        <section className="bg-white py-20">
          <div className="mx-auto max-w-3xl px-4 text-center sm:px-6 lg:px-8">
            <p className="text-lg leading-relaxed text-rich-mahogany-700/80">
              La reserva se coordina por WhatsApp. Escríbenos y te ayudamos a
              asignar tu mesa en pocos minutos.
            </p>
            <div className="mt-8">
              <WhatsAppButton
                variant="primary"
                message="reserve"
                label="Reservar mesa"
                size="lg"
              />
            </div>
          </div>
        </section>

        {/* Cómo reservar */}
        <section className="border-y border-rich-mahogany-100 bg-white py-20">
          <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
            <SectionTitle title="Cómo reservar" />
            <ol className="mt-10 space-y-6">
              {steps.map((step, i) => (
                <li key={i} className="flex items-start gap-4">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-rich-mahogany-600 font-serif font-bold text-cream">
                    {i + 1}
                  </span>
                  <p className="font-serif text-xl font-semibold text-rich-mahogany-600">
                    {step}
                  </p>
                </li>
              ))}
            </ol>
          </div>
        </section>

        {/* Info bloques */}
        <section className="bg-white py-20">
          <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 gap-8 md:grid-cols-3 md:divide-x md:divide-rich-mahogany-100">
              {/* Horario */}
              <div className="md:px-6">
                <Clock className="h-7 w-7 text-black-forest-700" strokeWidth={1.5} />
                <h3 className="mt-3 font-serif text-lg font-semibold text-rich-mahogany-950">
                  Horario
                </h3>
                <ul className="mt-3 space-y-1.5 text-sm text-rich-mahogany-700/80">
                  {business.hours.map((h) => (
                    <li key={h.day}>
                      <span className="font-medium text-rich-mahogany-950">{h.day}:</span>{' '}
                      {h.time}
                    </li>
                  ))}
                </ul>
              </div>
              {/* Dirección */}
              <div className="md:px-6">
                <MapPin className="h-7 w-7 text-black-forest-700" strokeWidth={1.5} />
                <h3 className="mt-3 font-serif text-lg font-semibold text-rich-mahogany-950">
                  Dirección
                </h3>
                <p className="mt-3 text-sm text-rich-mahogany-700/80">{business.address}</p>
                <a
                  href={business.mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-3 inline-block text-sm font-medium text-rich-mahogany-600 underline underline-offset-[0.25em] hover:text-rich-mahogany-700"
                >
                  Cómo llegar
                </a>
              </div>
              {/* Grupos */}
              <div className="md:px-6">
                <Users className="h-7 w-7 text-black-forest-700" strokeWidth={1.5} />
                <h3 className="mt-3 font-serif text-lg font-semibold text-rich-mahogany-950">
                  Grupos y eventos
                </h3>
                <p className="mt-3 text-sm text-rich-mahogany-700/80">
                  Si son más de 8 personas, escríbenos con anticipación.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section className="bg-white pb-20">
          <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
            <SectionTitle title="Preguntas frecuentes" />
            <div className="mt-10">
              <FaqAccordion items={faqs} />
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
