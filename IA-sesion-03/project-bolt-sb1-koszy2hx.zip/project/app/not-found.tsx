import Link from 'next/link';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { WhatsAppButton } from '@/components/WhatsAppButton';

export default function NotFound() {
  return (
    <>
      <Header />
      <main className="flex min-h-[60vh] items-center justify-center bg-white py-20">
        <div className="mx-auto max-w-xl px-4 text-center sm:px-6">
          <p className="font-serif text-6xl font-bold text-rich-mahogany-600">404</p>
          <h1 className="mt-4 font-serif text-3xl font-bold text-rich-mahogany-950">
            Esta página no está en la mesa
          </h1>
          <p className="mt-4 text-base text-rich-mahogany-700/80">
            Tal vez el enlace cambió o no existe. Vuelve al inicio para seguir
            explorando nuestra carta.
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Link
              href="/"
              className="inline-flex h-11 items-center justify-center rounded-full bg-champagne-mist-400 px-6 text-sm font-semibold text-rich-mahogany-950 transition-colors hover:bg-champagne-mist-500 focus-ring"
            >
              Volver al inicio
            </Link>
            <WhatsAppButton variant="secondary" message="delivery" label="Pedir a domicilio" className="border-rich-mahogany-600 text-rich-mahogany-600" />
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
