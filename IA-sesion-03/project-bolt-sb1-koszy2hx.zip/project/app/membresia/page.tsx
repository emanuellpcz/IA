import type { Metadata } from 'next';
import {
  Cake,
  Percent,
  Ticket,
  CalendarCheck,
  GlassWater,
} from 'lucide-react';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { SectionTitle } from '@/components/SectionTitle';
import { FaqAccordion } from '@/components/FaqAccordion';
import { WhatsAppButton } from '@/components/WhatsAppButton';

export const metadata: Metadata = {
  title: 'Club Comal | Membresía',
  description:
    'Únete al Club Comal y disfruta postre de cortesía en tu cumpleaños, descuento en domicilios, acceso anticipado a eventos y más beneficios.',
};

const benefits = [
  {
    icon: Cake,
    title: 'Postre de cortesía en tu cumpleaños',
    desc: 'Te celebramos con un postre de la casa, sin costo adicional.',
  },
  {
    icon: Percent,
    title: '10 % de descuento en tus domicilios',
    desc: 'Válido en todos los pedidos a domicilio que hagas como miembro.',
  },
  {
    icon: Ticket,
    title: 'Acceso anticipado a eventos y menús de temporada',
    desc: 'Entérate antes que nadie de nuestras cenas y ediciones especiales.',
  },
  {
    icon: CalendarCheck,
    title: 'Prioridad de reserva los fines de semana',
    desc: 'Te damos prioridad para asignar tu mesa en viernes, sábado y domingo.',
  },
  {
    icon: GlassWater,
    title: 'Bebida de bienvenida en tu primera visita de cada mes',
    desc: 'Empezamos cada mes contigo con una bebida de la casa, por cuenta nuestra.',
  },
];

const steps = [
  'Escríbenos por WhatsApp.',
  'Recibe tu código Club Comal.',
  'Disfruta tus beneficios en cada visita y pedido.',
];

const faqs = [
  {
    question: '¿Cuánto cuesta unirme?',
    answer: 'Nada. La inscripción al Club Comal no tiene costo.',
  },
  {
    question: '¿Cómo uso mis beneficios?',
    answer:
      'Muestra tu código Club Comal al hacer tu pedido o al pagar, y aplicamos tus beneficios automáticamente.',
  },
  {
    question: '¿Puedo compartir mi membresía?',
    answer:
      'No, los beneficios del Club Comal son personales e intransferibles.',
  },
];

export default function MembresiaPage() {
  return (
    <>
      <Header />
      <main>
        {/* Hero compacto */}
        <section className="relative flex min-h-[55vh] items-end overflow-hidden">
          <img
            src="https://images.pexels.com/photos/8158285/pexels-photo-8158285.jpeg?auto=compress&cs=tinysrgb&h=800&w=1400"
            alt="Familia celebrando juntos en una mesa con platillos mexicanos"
            width={1400}
            height={800}
            className="absolute inset-0 h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-rich-mahogany-950/55 via-rich-mahogany-950/55 to-rich-mahogany-950/70" />
          <div className="relative z-10 mx-auto w-full max-w-7xl px-4 pb-12 sm:px-6 lg:px-8">
            <h1
              className="font-serif font-bold leading-[1.05] text-cream"
              style={{ fontSize: 'clamp(2.25rem, 5vw, 4rem)' }}
            >
              Club Comal
            </h1>
            <p className="mt-3 max-w-xl text-lg text-cream/85">
              Una mesa con lugar para ti, siempre
            </p>
          </div>
        </section>

        {/* Beneficios */}
        <section className="bg-white py-20">
          <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
            <SectionTitle title="Beneficios del Club Comal" />
            <div className="mt-12 grid grid-cols-1 gap-x-10 gap-y-8 md:grid-cols-2">
              {benefits.map(({ icon: Icon, title, desc }) => (
                <div key={title} className="flex gap-4">
                  <Icon
                    className="mt-1 h-7 w-7 shrink-0 text-black-forest-700"
                    strokeWidth={1.5}
                  />
                  <div>
                    <h3 className="font-serif text-lg font-semibold text-rich-mahogany-950">
                      {title}
                    </h3>
                    <p className="mt-1 text-sm leading-relaxed text-rich-mahogany-700/80">
                      {desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Cómo funciona */}
        <section className="border-y border-rich-mahogany-100 bg-white py-20">
          <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
            <SectionTitle title="Cómo funciona" />
            <ol className="mt-10 space-y-6">
              {steps.map((step, i) => (
                <li key={i} className="flex items-start gap-4">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-rich-mahogany-600 font-serif font-bold text-cream">
                    {i + 1}
                  </span>
                  <p className="font-serif text-xl font-semibold text-rich-mahogany-600">
                    {step}
                  </p>
                </li>
              ))}
            </ol>
            <p className="mt-8 text-center text-sm font-medium text-black-forest-700">
              Sin costo de inscripción
            </p>
          </div>
        </section>

        {/* Bloque destacado */}
        <section className="bg-rich-mahogany-600 py-20 text-cream">
          <div className="mx-auto max-w-3xl px-4 text-center sm:px-6 lg:px-8">
            <p
              className="font-serif font-semibold italic text-cream"
              style={{ fontSize: 'clamp(1.75rem, 4vw, 2.5rem)', lineHeight: 1.2 }}
            >
              Siempre hay un lugar más en la mesa.
            </p>
            <div className="mt-8">
              <WhatsAppButton
                variant="primary"
                message="club"
                label="Únete ahora"
                size="lg"
              />
            </div>
          </div>
        </section>

        {/* Condiciones */}
        <section className="bg-white py-12">
          <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
            <p className="text-center text-xs leading-relaxed text-rich-mahogany-700/60">
              Los beneficios del Club Comal son personales e intransferibles, no
              acumulables con otras promociones y están sujetos a disponibilidad.
            </p>
          </div>
        </section>

        {/* FAQ */}
        <section className="bg-white pb-20">
          <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
            <SectionTitle title="Preguntas frecuentes" />
            <div className="mt-10">
              <FaqAccordion items={faqs} />
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
