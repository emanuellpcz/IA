import Link from 'next/link';
import { notFound } from 'next/navigation';
import type { Metadata } from 'next';
import { ChevronRight, ArrowLeft, ArrowRight } from 'lucide-react';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { TileStrip } from '@/components/TileStrip';
import { DishItem } from '@/components/DishItem';
import { WhatsAppButton } from '@/components/WhatsAppButton';
import { categories, getCategory } from '@/lib/menu';
import { cn } from '@/lib/utils';

export function generateStaticParams() {
  return categories.map((c) => ({ categoria: c.slug }));
}

export function generateMetadata({
  params,
}: {
  params: { categoria: string };
}): Metadata {
  const cat = getCategory(params.categoria);
  if (!cat) return { title: 'Categoría no encontrada | Comal de Casa' };
  return {
    title: cat.metaTitle,
    description: cat.metaDescription,
  };
}

export default function CategoryPage({
  params,
}: {
  params: { categoria: string };
}) {
  const cat = getCategory(params.categoria);
  if (!cat) notFound();

  const idx = categories.findIndex((c) => c.slug === cat.slug);
  const prev = categories[(idx - 1 + categories.length) % categories.length];
  const next = categories[(idx + 1) % categories.length];

  return (
    <>
      <Header />
      <main>
        {/* Hero compacto */}
        <section className="relative flex min-h-[55vh] items-end overflow-hidden">
          <img
            src={cat.heroImage}
            alt={cat.heroAlt}
            width={1400}
            height={800}
            className="absolute inset-0 h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-rich-mahogany-950/55 via-rich-mahogany-950/55 to-rich-mahogany-950/70" />
          <div className="relative z-10 mx-auto w-full max-w-7xl px-4 pb-12 sm:px-6 lg:px-8">
            {/* Migas */}
            <nav aria-label="Migas de pan" className="mb-4">
              <ol className="flex flex-wrap items-center gap-1.5 text-sm text-cream/85">
                <li>
                  <Link href="/" className="hover:text-cream underline-offset-[0.25em] hover:underline">
                    Inicio
                  </Link>
                </li>
                <li className="text-cream/60">/</li>
                <li>
                  <Link href="/#menu" className="hover:text-cream underline-offset-[0.25em] hover:underline">
                    Menú
                  </Link>
                </li>
                <li className="text-cream/60">/</li>
                <li className="font-medium text-cream">{cat.name}</li>
              </ol>
            </nav>
            <h1
              className="font-serif font-bold leading-[1.05] text-cream"
              style={{ fontSize: 'clamp(2.25rem, 5vw, 4rem)' }}
            >
              {cat.name}
            </h1>
            <p className="mt-3 max-w-xl text-lg text-cream/85">{cat.tagline}</p>
          </div>
        </section>

        {/* Introducción */}
        <section className="bg-white py-14">
          <div className="mx-auto max-w-3xl px-4 text-center sm:px-6">
            <p className="font-serif text-xl leading-relaxed text-rich-mahogany-700 sm:text-2xl">
              {cat.intro}
            </p>
          </div>
        </section>

        {/* Lista de platos */}
        <section className="bg-white pb-16">
          <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 gap-x-12 gap-y-8 md:grid-cols-2">
              {cat.dishes.map((dish) => (
                <DishItem key={dish.name} dish={dish} />
              ))}
            </div>
            {cat.note && (
              <p className="mt-10 text-center text-xs text-rich-mahogany-700/70">
                {cat.note}
              </p>
            )}
          </div>
        </section>

        {/* Galería */}
        <section className="bg-white pb-20">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              {cat.gallery.map((img) => (
                <div
                  key={img.src}
                  className="aspect-[3/2] overflow-hidden rounded-[4px]"
                >
                  <img
                    src={img.src}
                    alt={img.alt}
                    width={900}
                    height={600}
                    className="h-full w-full object-cover"
                  />
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Navegación entre categorías */}
        <section className="border-y border-rich-mahogany-100 bg-white py-14">
          <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
            <h2 className="text-center font-serif text-xl font-semibold text-rich-mahogany-950">
              Otras categorías
            </h2>
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              {categories.map((c) => (
                <Link
                  key={c.slug}
                  href={`/menu/${c.slug}`}
                  className={cn(
                    'rounded-full border px-4 py-2 text-sm font-medium transition-colors focus-ring',
                    c.slug === cat.slug
                      ? 'border-rich-mahogany-600 bg-rich-mahogany-600 text-cream'
                      : 'border-rich-mahogany-200 text-rich-mahogany-700 hover:border-rich-mahogany-400 hover:text-rich-mahogany-600'
                  )}
                >
                  {c.shortName}
                </Link>
              ))}
            </div>
            <div className="mt-8 flex flex-col items-center justify-between gap-4 sm:flex-row">
              <Link
                href={`/menu/${prev.slug}`}
                className="inline-flex items-center gap-2 text-sm font-medium text-rich-mahogany-600 underline underline-offset-[0.25em] hover:text-rich-mahogany-700"
              >
                <ArrowLeft className="h-4 w-4" />
                Categoría anterior: {prev.shortName}
              </Link>
              <Link
                href={`/menu/${next.slug}`}
                className="inline-flex items-center gap-2 text-sm font-medium text-rich-mahogany-600 underline underline-offset-[0.25em] hover:text-rich-mahogany-700"
              >
                Categoría siguiente: {next.shortName}
                <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </section>

        {/* Cierre */}
        <section className="bg-white py-20">
          <div className="mx-auto max-w-3xl px-4 text-center sm:px-6">
            <h2
              className="font-serif font-bold text-rich-mahogany-950"
              style={{ fontSize: 'clamp(2rem, 4vw, 3rem)' }}
            >
              Pásale, que la mesa ya está servida
            </h2>
            <div className="mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row">
              <WhatsAppButton variant="primary" message="delivery" label="Pedir a domicilio" size="lg" />
              <Link
                href="/reservas"
                className="inline-flex h-14 items-center justify-center rounded-full border-[1.5px] border-rich-mahogany-600 px-8 text-base font-semibold text-rich-mahogany-600 transition-colors hover:bg-rich-mahogany-50 focus-ring"
              >
                Reservar mesa
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
