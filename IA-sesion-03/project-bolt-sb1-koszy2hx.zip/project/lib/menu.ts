export type DishTag = 'Vegetariano' | 'Picante';

export interface Dish {
  name: string;
  description: string;
  price: number;
  tags?: DishTag[];
}

export interface MenuCategory {
  slug: string;
  name: string;
  shortName: string;
  tagline: string;
  intro: string;
  heroImage: string;
  heroAlt: string;
  cardImage: string;
  cardAlt: string;
  cardText: string;
  gallery: { src: string; alt: string }[];
  dishes: Dish[];
  metaTitle: string;
  metaDescription: string;
  note?: string;
}

export const categories: MenuCategory[] = [
  {
    slug: 'entradas',
    name: 'Entradas',
    shortName: 'Entradas',
    tagline: 'Para abrir la mesa con salsas y maíz tierno',
    intro:
      'Para abrir la mesa: salsas de molcajete, maíz tierno y tostadas recién hechas.',
    heroImage:
      'https://images.pexels.com/photos/27603320/pexels-photo-27603320.jpeg?auto=compress&cs=tinysrgb&h=800&w=1400',
    heroAlt: 'Entradas mexicanas con guacamole, salsas y totopos en mesa de barro',
    cardImage:
      'https://images.pexels.com/photos/4411802/pexels-photo-4411802.jpeg?auto=compress&cs=tinysrgb&h=800&w=640',
    cardAlt: 'Guacamole fresco con totopos en molcajete',
    cardText:
      'Guacamole al momento, esquites, sopa de tortilla, tostadas de tinga y ceviche estilo Baja.',
    gallery: [
      {
        src: 'https://images.pexels.com/photos/7613681/pexels-photo-7613681.jpeg?auto=compress&cs=tinysrgb&h=600&w=900',
        alt: 'Guacamole fresco con tomate y cebolla en cuenco de madera',
      },
      {
        src: 'https://images.pexels.com/photos/15481463/pexels-photo-15481463.jpeg?auto=compress&cs=tinysrgb&h=600&w=900',
        alt: 'Bowl de guacamole con verduras picadas en mesa rústica',
      },
      {
        src: 'https://images.pexels.com/photos/28667862/pexels-photo-28667862.jpeg?auto=compress&cs=tinysrgb&h=600&w=900',
        alt: 'Plato de desayuno mexicano con huevos, frijoles y tortilla',
      },
    ],
    dishes: [
      {
        name: 'Guacamole de molcajete',
        description:
          'Aguacate Hass, cebolla, cilantro, limón y chile serrano, con totopos de maíz.',
        price: 28900,
        tags: ['Vegetariano'],
      },
      {
        name: 'Esquites de la casa',
        description:
          'Maíz tierno en mantequilla, epazote, mayonesa, queso cotija y chile piquín.',
        price: 18900,
        tags: ['Vegetariano', 'Picante'],
      },
      {
        name: 'Sopa de tortilla',
        description:
          'Caldo de jitomate asado y chile pasilla, tiras de tortilla, aguacate, crema y queso panela.',
        price: 22900,
      },
      {
        name: 'Tostadas de tinga',
        description:
          'Pollo deshebrado en chipotle, frijoles refritos, lechuga y crema.',
        price: 24900,
        tags: ['Picante'],
      },
      {
        name: 'Ceviche estilo Baja',
        description:
          'Pescado blanco curado en limón, pepino, cilantro y chile, con tostadas.',
        price: 32900,
      },
      {
        name: 'Queso fundido con chorizo',
        description:
          'Queso Oaxaca gratinado, chorizo artesanal y tortillas de maíz.',
        price: 29900,
      },
    ],
    metaTitle: 'Entradas | Comal de Casa',
    metaDescription:
      'Guacamole de molcajete, esquites, sopa de tortilla, tostadas de tinga y ceviche estilo Baja para abrir la mesa.',
  },
  {
    slug: 'tacos',
    name: 'Tacos',
    shortName: 'Tacos',
    tagline: 'Tortilla hecha a diario, cocción lenta y salsas de la casa',
    intro:
      'Tortilla de maíz hecha a diario, cocción lenta y salsas de la casa. Cada orden trae tres tacos.',
    heroImage:
      'https://images.pexels.com/photos/4958779/pexels-photo-4958779.jpeg?auto=compress&cs=tinysrgb&h=800&w=1400',
    heroAlt: 'Tacos mexicanos con cilantro, limón y salsa sobre mesa de madera',
    cardImage:
      'https://images.pexels.com/photos/8448180/pexels-photo-8448180.jpeg?auto=compress&cs=tinysrgb&h=800&w=640',
    cardAlt: 'Tres tacos mexicanos callejeros con guarniciones',
    cardText:
      'Al pastor, cochinita pibil, birria, carnitas, nopal asado y pescado estilo Baja.',
    gallery: [
      {
        src: 'https://images.pexels.com/photos/4958521/pexels-photo-4958521.jpeg?auto=compress&cs=tinysrgb&h=600&w=900',
        alt: 'Tacos mexicanos con guarniciones y limón',
      },
      {
        src: 'https://images.pexels.com/photos/33614213/pexels-photo-33614213.jpeg?auto=compress&cs=tinysrgb&h=600&w=900',
        alt: 'Tacos coloridos con distintos rellenos en mesa de madera',
      },
      {
        src: 'https://images.pexels.com/photos/4958781/pexels-photo-4958781.jpeg?auto=compress&cs=tinysrgb&h=600&w=900',
        alt: 'Tacos con cilantro fresco, limón y toppings',
      },
    ],
    dishes: [
      {
        name: 'Tacos al pastor',
        description:
          'Cerdo adobado en achiote, piña asada, cebolla y cilantro.',
        price: 29900,
      },
      {
        name: 'Tacos de cochinita pibil',
        description:
          'Cerdo marinado en achiote y naranja agria, cebolla morada encurtida.',
        price: 29900,
      },
      {
        name: 'Tacos de birria con consomé',
        description:
          'Res cocida lentamente en chiles secos, queso y consomé para sopear.',
        price: 34900,
        tags: ['Picante'],
      },
      {
        name: 'Tacos de carnitas',
        description:
          'Cerdo confitado en su grasa, cebolla, cilantro y salsa verde.',
        price: 28900,
      },
      {
        name: 'Tacos de nopal asado',
        description:
          'Nopal a la plancha, queso panela, pico de gallo y frijoles.',
        price: 24900,
        tags: ['Vegetariano'],
      },
      {
        name: 'Tacos de pescado estilo Baja',
        description:
          'Pescado apanado, repollo morado, crema de chipotle y limón.',
        price: 32900,
      },
    ],
    metaTitle: 'Tacos | Comal de Casa',
    metaDescription:
      'Tacos al pastor, cochinita pibil, birria con consomé, carnitas, nopal asado y pescado estilo Baja con tortilla hecha a diario.',
  },
  {
    slug: 'antojitos',
    name: 'Antojitos',
    shortName: 'Antojitos',
    tagline: 'De la masa al comal, antojos de la cocina de casa',
    intro: 'Los antojos de la cocina de casa, de la masa al comal.',
    heroImage:
      'https://images.pexels.com/photos/32351725/pexels-photo-32351725.jpeg?auto=compress&cs=tinysrgb&h=800&w=1400',
    heroAlt: 'Quesadillas mexicanas con salsa y guacamole en mesa rústica',
    cardImage:
      'https://images.pexels.com/photos/33490796/pexels-photo-33490796.jpeg?auto=compress&cs=tinysrgb&h=800&w=640',
    cardAlt: 'Tamales mexicanos servidos con verduras en mesa de madera',
    cardText:
      'Quesadillas, tlayuda, sopes, chilaquiles, tamales y gorditas hechas a diario.',
    gallery: [
      {
        src: 'https://images.pexels.com/photos/12334113/pexels-photo-12334113.jpeg?auto=compress&cs=tinysrgb&h=600&w=900',
        alt: 'Manos preparando tamales mexicanos tradicionales con masa',
      },
      {
        src: 'https://images.pexels.com/photos/14179987/pexels-photo-14179987.jpeg?auto=compress&cs=tinysrgb&h=600&w=900',
        alt: 'Tamal tradicional mexicano servido con salsa en mesa de madera',
      },
      {
        src: 'https://images.pexels.com/photos/15750738/pexels-photo-15750738.jpeg?auto=compress&cs=tinysrgb&h=600&w=900',
        alt: 'Quesadillas con papas fritas y cerveza en mesa de restaurante',
      },
    ],
    dishes: [
      {
        name: 'Quesadillas de flor de calabaza',
        description: 'Tortilla de maíz azul, queso Oaxaca y epazote.',
        price: 22900,
        tags: ['Vegetariano'],
      },
      {
        name: 'Tlayuda oaxaqueña',
        description:
          'Tortilla crujiente con asiento, frijoles, quesillo, tasajo y aguacate.',
        price: 36900,
      },
      {
        name: 'Sopes de chorizo y papa',
        description:
          'Masa gruesa, frijoles, chorizo, papa, lechuga y queso fresco.',
        price: 23900,
      },
      {
        name: 'Chilaquiles verdes con pollo',
        description:
          'Totopos en salsa verde, pollo, crema, cebolla y queso.',
        price: 26900,
        tags: ['Picante'],
      },
      {
        name: 'Tamales de elote (2 unidades)',
        description: 'Masa de maíz tierno envuelta en hoja, con crema y queso.',
        price: 19900,
        tags: ['Vegetariano'],
      },
      {
        name: 'Gorditas de chicharrón prensado',
        description: 'Masa de maíz rellena, salsa roja y queso fresco.',
        price: 22900,
        tags: ['Picante'],
      },
    ],
    metaTitle: 'Antojitos | Comal de Casa',
    metaDescription:
      'Quesadillas de flor de calabaza, tlayuda oaxaqueña, sopes, chilaquiles, tamales de elote y gorditas hechas a diario.',
  },
  {
    slug: 'platos-fuertes',
    name: 'Platos fuertes',
    shortName: 'Platos fuertes',
    tagline: 'Guisos de olla grande para cuando la familia se reúne',
    intro: 'Guisos de olla grande, de esos que se sirven cuando la familia se reúne.',
    heroImage:
      'https://images.pexels.com/photos/27603300/pexels-photo-27603300.jpeg?auto=compress&cs=tinysrgb&h=800&w=1400',
    heroAlt: 'Plato de mole mexicano con arroz y frijoles en mesa rústica',
    cardImage:
      'https://images.pexels.com/photos/34035523/pexels-photo-34035523.jpeg?auto=compress&cs=tinysrgb&h=800&w=640',
    cardAlt: 'Plato de cocina mexicana tradicional con mole, arroz y guarnición',
    cardText:
      'Mole poblano, enchiladas, chiles rellenos, cochinita pibil, pozole y pescado a la veracruzana.',
    gallery: [
      {
        src: 'https://images.pexels.com/photos/27603317/pexels-photo-27603317.jpeg?auto=compress&cs=tinysrgb&h=600&w=900',
        alt: 'Enchiladas mexicanas con arroz y frijoles en mesa de madera',
      },
      {
        src: 'https://images.pexels.com/photos/27603313/pexels-photo-27603313.jpeg?auto=compress&cs=tinysrgb&h=600&w=900',
        alt: 'Plato de mole con frijoles negros y arroz en mesa rústica',
      },
      {
        src: 'https://images.pexels.com/photos/27603299/pexels-photo-27603299.jpeg?auto=compress&cs=tinysrgb&h=600&w=900',
        alt: 'Mole tradicional mexicano servido con arroz y frijoles',
      },
    ],
    dishes: [
      {
        name: 'Mole poblano con pollo',
        description:
          'Muslo y pierna en mole de chiles, almendra y chocolate, arroz rojo y ajonjolí.',
        price: 42900,
      },
      {
        name: 'Enchiladas verdes',
        description:
          'Tortillas rellenas de pollo, salsa de tomatillo, crema y queso fresco.',
        price: 38900,
        tags: ['Picante'],
      },
      {
        name: 'Chiles rellenos',
        description:
          'Chile poblano relleno de queso, capeado, en salsa de jitomate asado.',
        price: 39900,
        tags: ['Vegetariano'],
      },
      {
        name: 'Cochinita pibil',
        description:
          'Cerdo en achiote y naranja agria cocido en hoja, arroz, frijoles y cebolla encurtida.',
        price: 44900,
      },
      {
        name: 'Pozole rojo',
        description:
          'Maíz cacahuazintle, cerdo, chile guajillo, rábano, lechuga y orégano.',
        price: 36900,
        tags: ['Picante'],
      },
      {
        name: 'Pescado a la veracruzana',
        description:
          'Filete en salsa de jitomate, aceitunas, alcaparras y chile güero.',
        price: 48900,
      },
    ],
    metaTitle: 'Platos fuertes | Comal de Casa',
    metaDescription:
      'Mole poblano, enchiladas verdes, chiles rellenos, cochinita pibil, pozole rojo y pescado a la veracruzana.',
  },
  {
    slug: 'parrilla',
    name: 'Parrilla',
    shortName: 'Parrilla',
    tagline: 'Brasa y sazón de siempre con guarniciones de la casa',
    intro:
      'Brasa y sazón de siempre, con guarniciones de cebollitas, nopal y frijoles charros.',
    heroImage:
      'https://images.pexels.com/photos/5539072/pexels-photo-5539072.jpeg?auto=compress&cs=tinysrgb&h=800&w=1400',
    heroAlt: 'Carne asada a la parrilla con cebolla y tomate en brasas',
    cardImage:
      'https://images.pexels.com/photos/31617225/pexels-photo-31617225.jpeg?auto=compress&cs=tinysrgb&h=800&w=640',
    cardAlt: 'Filetes de carne asada en parrilla rústica',
    cardText:
      'Arrachera, chuleta adobada, costillas de chipotle, alambre y parrilladas para compartir.',
    gallery: [
      {
        src: 'https://images.pexels.com/photos/13443236/pexels-photo-13443236.jpeg?auto=compress&cs=tinysrgb&h=600&w=900',
        alt: 'Chuletas de cordero asadas con salsa y verduras',
      },
      {
        src: 'https://images.pexels.com/photos/18852565/pexels-photo-18852565.jpeg?auto=compress&cs=tinysrgb&h=600&w=900',
        alt: 'Filete de carne con verduras frescas y tortillas en tabla de madera',
      },
      {
        src: 'https://images.pexels.com/photos/37667720/pexels-photo-37667720.jpeg?auto=compress&cs=tinysrgb&h=600&w=900',
        alt: 'Carne asada con cebolla y verduras a la parrilla',
      },
    ],
    dishes: [
      {
        name: 'Arrachera a la parrilla (300 g)',
        description:
          'Res marinada en limón y ajo, con cebollitas cambray y tortillas.',
        price: 62900,
      },
      {
        name: 'Chuleta de cerdo adobada',
        description:
          'Chuleta gruesa en adobo de chile ancho, con nopal asado.',
        price: 52900,
      },
      {
        name: 'Costillas de chipotle',
        description: 'Costillas de cerdo glaseadas en salsa de chipotle y miel.',
        price: 58900,
        tags: ['Picante'],
      },
      {
        name: 'Alambre de res',
        description:
          'Res, tocino, pimentón y queso gratinado, con tortillas.',
        price: 49900,
      },
      {
        name: 'Pollo al carbón con achiote',
        description: 'Medio pollo marinado, arroz y ensalada fresca.',
        price: 44900,
      },
      {
        name: 'Parrillada para compartir (2 a 3 personas)',
        description:
          'Arrachera, chuleta, chorizo, pollo, nopal, cebollitas y frijoles charros.',
        price: 138900,
      },
    ],
    metaTitle: 'Parrilla | Comal de Casa',
    metaDescription:
      'Arrachera, chuleta adobada, costillas de chipotle, alambre de res y parrillada para compartir con guarniciones de la casa.',
  },
  {
    slug: 'postres',
    name: 'Postres',
    shortName: 'Postres',
    tagline: 'Dulces de la abuela, de cajeta, canela y maíz',
    intro: 'Para la sobremesa: dulces de la abuela, de cajeta, canela y maíz.',
    heroImage:
      'https://images.pexels.com/photos/37924356/pexels-photo-37924356.jpeg?auto=compress&cs=tinysrgb&h=800&w=1400',
    heroAlt: 'Churros con chocolate y cajeta en presentación rústica',
    cardImage:
      'https://images.pexels.com/photos/37543728/pexels-photo-37543728.jpeg?auto=compress&cs=tinysrgb&h=800&w=640',
    cardAlt: 'Churros bañados en chocolate con fresas',
    cardText:
      'Churros con chocolate y cajeta, flan, pastel de tres leches, pastel de elote y arroz con leche.',
    gallery: [
      {
        src: 'https://images.pexels.com/photos/37228442/pexels-photo-37228442.jpeg?auto=compress&cs=tinysrgb&h=600&w=900',
        alt: 'Rebanada de pastel de tres leches con cerezas',
      },
      {
        src: 'https://images.pexels.com/photos/36616787/pexels-photo-36616787.jpeg?auto=compress&cs=tinysrgb&h=600&w=900',
        alt: 'Flan de caramelo con cobertura de ciruela en plato blanco',
      },
      {
        src: 'https://images.pexels.com/photos/37924300/pexels-photo-37924300.jpeg?auto=compress&cs=tinysrgb&h=600&w=900',
        alt: 'Canasta de churros recién hechos con chocolate',
      },
    ],
    dishes: [
      {
        name: 'Churros con chocolate y cajeta',
        description: 'Recién fritos, con azúcar y canela.',
        price: 19900,
        tags: ['Vegetariano'],
      },
      {
        name: 'Flan napolitano',
        description: 'De vainilla, con caramelo oscuro.',
        price: 15900,
        tags: ['Vegetariano'],
      },
      {
        name: 'Pastel de tres leches',
        description: 'Bizcocho esponjoso, crema chantilly y canela.',
        price: 16900,
        tags: ['Vegetariano'],
      },
      {
        name: 'Pastel de elote con helado',
        description: 'Textura húmeda de maíz tierno, con helado de vainilla.',
        price: 17900,
        tags: ['Vegetariano'],
      },
      {
        name: 'Arroz con leche',
        description: 'Cocido lento con canela en rama y piel de naranja.',
        price: 13900,
        tags: ['Vegetariano'],
      },
    ],
    metaTitle: 'Postres | Comal de Casa',
    metaDescription:
      'Churros con chocolate y cajeta, flan napolitano, pastel de tres leches, pastel de elote y arroz con leche.',
  },
  {
    slug: 'bebidas',
    name: 'Bebidas',
    shortName: 'Bebidas',
    tagline: 'Aguas frescas, café de olla y chocolate de molino',
    intro: 'Aguas frescas de fruta y semilla, café de olla y chocolate de molino.',
    heroImage:
      'https://images.pexels.com/photos/34567239/pexels-photo-34567239.jpeg?auto=compress&cs=tinysrgb&h=800&w=1400',
    heroAlt: 'Agua de jamaica servida con menta y limón en frasco de vidrio',
    cardImage:
      'https://images.pexels.com/photos/34567560/pexels-photo-34567560.jpeg?auto=compress&cs=tinysrgb&h=800&w=640',
    cardAlt: 'Horchata mexicana tradicional con canela en frasco',
    cardText:
      'Aguas frescas, horchata, café de olla, chocolate caliente y limonadas.',
    gallery: [
      {
        src: 'https://images.pexels.com/photos/34566510/pexels-photo-34566510.jpeg?auto=compress&cs=tinysrgb&h=600&w=900',
        alt: 'Horchata mexicana con canela en taza de vidrio',
      },
      {
        src: 'https://images.pexels.com/photos/37663515/pexels-photo-37663515.jpeg?auto=compress&cs=tinysrgb&h=600&w=900',
        alt: 'Puesto de bebidas mexicanas tradicionales con jícaras',
      },
      {
        src: 'https://images.pexels.com/photos/34508595/pexels-photo-34508595.jpeg?auto=compress&cs=tinysrgb&h=600&w=900',
        alt: 'Horchata tradicional servida en frasco con canela',
      },
    ],
    dishes: [
      {
        name: 'Agua fresca de jamaica',
        description: 'Flor de jamaica y un toque de limón.',
        price: 9900,
        tags: ['Vegetariano'],
      },
      {
        name: 'Horchata',
        description: 'Arroz, canela y vainilla.',
        price: 10900,
        tags: ['Vegetariano'],
      },
      {
        name: 'Agua de tamarindo',
        description: 'Tamarindo natural con borde de chile.',
        price: 9900,
        tags: ['Vegetariano'],
      },
      {
        name: 'Limonada con hierbabuena',
        description: 'Limón natural, hierbabuena y hielo.',
        price: 10900,
        tags: ['Vegetariano'],
      },
      {
        name: 'Café de olla',
        description: 'Café con piloncillo y canela.',
        price: 8900,
        tags: ['Vegetariano'],
      },
      {
        name: 'Chocolate caliente mexicano',
        description: 'Chocolate de metate, canela y leche.',
        price: 11900,
        tags: ['Vegetariano'],
      },
    ],
    metaTitle: 'Bebidas | Comal de Casa',
    metaDescription:
      'Agua fresca de jamaica, horchata, agua de tamarindo, limonada con hierbabuena, café de olla y chocolate caliente mexicano.',
  },
  {
    slug: 'cocteles-y-licores',
    name: 'Cócteles y licores',
    shortName: 'Cócteles y licores',
    tagline: 'Margaritas de la casa, mezcales y clásicos de cantina',
    intro:
      'La sobremesa también se sirve en copa: margaritas de la casa, mezcales y clásicos de cantina.',
    heroImage:
      'https://images.pexels.com/photos/28525104/pexels-photo-28525104.jpeg?auto=compress&cs=tinysrgb&h=800&w=1400',
    heroAlt: 'Margarita con hielo y limón en mesa de madera',
    cardImage:
      'https://images.pexels.com/photos/7603328/pexels-photo-7603328.jpeg?auto=compress&cs=tinysrgb&h=800&w=640',
    cardAlt: 'Margarita mexicana con limón en primer plano',
    cardText:
      'Margaritas, palomas, micheladas, mezcales, tequilas y cervezas mexicanas.',
    gallery: [
      {
        src: 'https://images.pexels.com/photos/34566506/pexels-photo-34566506.jpeg?auto=compress&cs=tinysrgb&h=600&w=900',
        alt: 'Tequila con limón y sal en superficie de madera',
      },
      {
        src: 'https://images.pexels.com/photos/34508623/pexels-photo-34508623.jpeg?auto=compress&cs=tinysrgb&h=600&w=900',
        alt: 'Tequila con rodajas de limón y sal en barra con luz cálida',
      },
      {
        src: 'https://images.pexels.com/photos/32912385/pexels-photo-32912385.jpeg?auto=compress&cs=tinysrgb&h=600&w=900',
        alt: 'Tequila clásico con limón y borde de sal en mesa de madera',
      },
    ],
    dishes: [
      {
        name: 'Margarita de la casa',
        description: 'Tequila blanco, limón, triple sec y borde de sal.',
        price: 29900,
      },
      {
        name: 'Margarita de tamarindo y chile',
        description: 'Tequila reposado, pulpa de tamarindo y borde de chile.',
        price: 32900,
        tags: ['Picante'],
      },
      {
        name: 'Paloma',
        description: 'Tequila, toronja, limón y soda con borde de sal.',
        price: 28900,
      },
      {
        name: 'Michelada clásica',
        description: 'Cerveza, limón, salsas, sal y borde de chile.',
        price: 19900,
        tags: ['Picante'],
      },
      {
        name: 'Copa de mezcal artesanal (2 oz)',
        description: 'Con naranja y sal de gusano.',
        price: 34900,
      },
      {
        name: 'Tequila reposado (2 oz)',
        description: 'Servido derecho, con sangrita.',
        price: 32900,
      },
      {
        name: 'Cerveza mexicana',
        description: 'Botella de 355 ml, con limón y sal.',
        price: 14900,
      },
      {
        name: 'Carajillo',
        description: 'Licor 43, espresso y hielo.',
        price: 27900,
      },
    ],
    metaTitle: 'Cócteles y licores | Comal de Casa',
    metaDescription:
      'Margaritas de la casa, paloma, michelada, mezcal artesanal, tequila reposado, cerveza mexicana y carajillo.',
    note: 'Consume licor con responsabilidad. Prohibida la venta de licor a menores de 18 años.',
  },
];

export const getCategory = (slug: string) =>
  categories.find((c) => c.slug === slug);

export const formatPrice = (price: number) =>
  `$${price.toLocaleString('es-CO')}`;
