export const business = {
  name: 'Comal de Casa',
  slogan: 'Tradición que nos reúne',
  phone: '+57 300 123 4567',
  phoneDigits: '573001234567',
  email: 'hola@comaldecasa.co',
  instagram: 'comaldecasa',
  instagramUrl: 'https://instagram.com/comaldecasa',
  address: 'Calle 72 # 11-30, Chapinero, Bogotá',
  hours: [
    { day: 'Lunes a jueves', time: '12:00 m. a 10:00 p. m.' },
    { day: 'Viernes y sábado', time: '12:00 m. a 12:00 a. m.' },
    { day: 'Domingos y festivos', time: '11:00 a. m. a 8:00 p. m.' },
  ],
  mapsUrl:
    'https://www.google.com/maps/search/?api=1&query=Calle+72+11-30+Chapinero+Bogota',
  mapsEmbed:
    'https://images.pexels.com/photos/11815816/pexels-photo-11815816.jpeg?auto=compress&cs=tinysrgb&h=300&w=500',
  about:
    'En Comal de Casa cocinamos las recetas que se heredan en la mesa familiar: tortillas hechas a diario, salsas de molcajete y guisos de cocción lenta. Siempre hay un lugar más en la mesa.',
};

export const whatsappUrl = (
  message: string,
  phone: string = business.phoneDigits
) => `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;

export const messages = {
  delivery: whatsappUrl(
    'Hola Comal de Casa, quiero pedir a domicilio. ¿Me ayudas con mi pedido?'
  ),
  reserve: whatsappUrl(
    'Hola Comal de Casa, quiero reservar una mesa. ¿Me ayudas con la disponibilidad?'
  ),
  club: whatsappUrl(
    'Hola Comal de Casa, quiero unirme al Club Comal. ¿Cómo hago para recibir mi código?'
  ),
};
