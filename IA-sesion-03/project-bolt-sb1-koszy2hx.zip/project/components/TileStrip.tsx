import { cn } from '@/lib/utils';

export function TileStrip({ className }: { className?: string }) {
  return (
    <div
      className={cn(
        'w-full overflow-hidden bg-rich-mahogany-950',
        className
      )}
      aria-hidden="true"
    >
      <svg
        width="100%"
        height="20"
        viewBox="0 0 48 20"
        preserveAspectRatio="xMidYMid meet"
        className="block h-5 w-full"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <pattern
            id="tile-pattern"
            x="0"
            y="0"
            width="24"
            height="20"
            patternUnits="userSpaceOnUse"
          >
            {/* rombo central champagne */}
            <path d="M12 2 L20 10 L12 18 L4 10 Z" fill="#f6be6f" opacity="0.9" />
            {/* triángulos rojo caoba */}
            <path d="M0 0 L12 10 L0 20 Z" fill="#b01c25" />
            <path d="M24 0 L12 10 L24 20 Z" fill="#b01c25" />
            {/* acento verde */}
            <circle cx="12" cy="10" r="1.6" fill="#386d2c" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#tile-pattern)" />
      </svg>
    </div>
  );
}
