import { cn } from '@/lib/utils';

interface LogoProps {
  variant?: 'dark' | 'light';
  className?: string;
  showWordmark?: boolean;
}

const mahoganyDark = '#84151c';
const mahoganyLight = '#f5ece0';
const forestGreen = '#386d2c';

export function Logo({ variant = 'dark', className, showWordmark = true }: LogoProps) {
  const symbolColor = variant === 'dark' ? mahoganyDark : mahoganyLight;
  const wordmarkColor = variant === 'dark' ? 'text-rich-mahogany-700' : 'text-cream';
  const greenColor = variant === 'dark' ? forestGreen : '#b9e0b0';

  return (
    <span className={cn('inline-flex items-center gap-2.5', className)}>
      <svg
        width="44"
        height="44"
        viewBox="0 0 44 44"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
        className="shrink-0"
      >
        {/* Vapor */}
        <path
          d="M17 4c-1.2 1.5-1.2 3 0 4.5s1.2 3 0 4.5"
          stroke={symbolColor}
          strokeWidth="1.5"
          strokeLinecap="round"
        />
        <path
          d="M22 3c-1.2 1.5-1.2 3 0 4.5s1.2 3 0 4.5"
          stroke={symbolColor}
          strokeWidth="1.5"
          strokeLinecap="round"
        />
        <path
          d="M27 4c-1.2 1.5-1.2 3 0 4.5s1.2 3 0 4.5"
          stroke={symbolColor}
          strokeWidth="1.5"
          strokeLinecap="round"
        />
        {/* Comal */}
        <ellipse
          cx="22"
          cy="28"
          rx="15"
          ry="4.5"
          stroke={symbolColor}
          strokeWidth="1.5"
        />
        <path
          d="M7 28c0 2.5 6.7 4.5 15 4.5s15-2 15-4.5"
          stroke={symbolColor}
          strokeWidth="1.5"
        />
        {/* Mazorca */}
        <path
          d="M18.5 24c0-2 1.5-3.5 3.5-3.5s3.5 1.5 3.5 3.5"
          stroke={symbolColor}
          strokeWidth="1.5"
          strokeLinecap="round"
        />
        <ellipse cx="22" cy="24" rx="2" ry="2.5" stroke={symbolColor} strokeWidth="1.5" />
        <path d="M20 22.5l1-1.5M21.3 22.2l.8-1.7M22.6 22.2l.6-1.7M23.8 22.5l.4-1.5" stroke={greenColor} strokeWidth="1.2" strokeLinecap="round" />
      </svg>
      {showWordmark && (
        <span
          className={cn(
            'font-serif font-bold leading-none tracking-tight',
            wordmarkColor
          )}
          style={{ fontSize: '1.4rem' }}
        >
          Comal de Casa
        </span>
      )}
    </span>
  );
}
