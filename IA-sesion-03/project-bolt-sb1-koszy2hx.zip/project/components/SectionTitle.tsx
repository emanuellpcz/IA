import { cn } from '@/lib/utils';

interface SectionTitleProps {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  align?: 'center' | 'left';
  className?: string;
  light?: boolean;
}

export function SectionTitle({
  eyebrow,
  title,
  subtitle,
  align = 'center',
  className,
  light = false,
}: SectionTitleProps) {
  return (
    <div
      className={cn(
        'max-w-2xl',
        align === 'center' ? 'mx-auto text-center' : 'text-left',
        className
      )}
    >
      {eyebrow && (
        <p
          className={cn(
            'mb-3 text-sm font-semibold uppercase tracking-wider',
            light ? 'text-champagne-mist-300' : 'text-rich-mahogany-600'
          )}
        >
          {eyebrow}
        </p>
      )}
      <h2
        className={cn(
          'font-serif font-bold leading-tight text-balance',
          light ? 'text-cream' : 'text-rich-mahogany-950'
        )}
        style={{ fontSize: 'clamp(2rem, 4vw, 3.25rem)' }}
      >
        {title}
      </h2>
      {align === 'center' && (
        <div className="mx-auto mt-5 h-px w-16 bg-black-forest-700" />
      )}
      {subtitle && (
        <p
          className={cn(
            'mt-5 text-lg leading-relaxed',
            light ? 'text-cream/80' : 'text-rich-mahogany-700/80'
          )}
        >
          {subtitle}
        </p>
      )}
    </div>
  );
}
