import { formatPrice, type Dish } from '@/lib/menu';
import { cn } from '@/lib/utils';

export function DishItem({ dish }: { dish: Dish }) {
  return (
    <div className="border-b border-rich-mahogany-100 pb-5">
      <div className="flex items-baseline justify-between gap-4">
        <h3
          className="font-serif font-semibold text-rich-mahogany-950"
          style={{ fontSize: '1.5rem', lineHeight: 1.2 }}
        >
          {dish.name}
        </h3>
        <span className="shrink-0 font-sans font-bold text-rich-mahogany-700">
          {formatPrice(dish.price)}
        </span>
      </div>
      <p className="mt-2 text-sm leading-relaxed text-rich-mahogany-700/80 sm:text-base">
        {dish.description}
      </p>
      {dish.tags && dish.tags.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-2">
          {dish.tags.map((tag) => (
            <span
              key={tag}
              className={cn(
                'inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-medium',
                tag === 'Vegetariano'
                  ? 'border-black-forest-600/30 text-black-forest-800'
                  : 'border-rich-mahogany-600/30 text-rich-mahogany-700'
              )}
            >
              <span
                className={cn(
                  'h-1.5 w-1.5 rounded-full',
                  tag === 'Vegetariano' ? 'bg-black-forest-600' : 'bg-rich-mahogany-600'
                )}
              />
              {tag}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}
