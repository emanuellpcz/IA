import Link from 'next/link';
import { Instagram, Phone, Mail, MapPin, Clock } from 'lucide-react';
import { Logo } from '@/components/Logo';
import { TileStrip } from '@/components/TileStrip';
import { business, whatsappUrl, messages } from '@/lib/business';

export function Footer() {
  return (
    <footer id="contacto" className="bg-rich-mahogany-950 text-cream">
      <TileStrip />
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-2 lg:grid-cols-4 lg:divide-x lg:divide-rich-mahogany-800">
          {/* Logo */}
          <div className="lg:pr-8">
            <Logo variant="light" />
            <p className="mt-5 text-sm leading-relaxed text-cream/70">
              {business.slogan}
            </p>
          </div>

          {/* Nosotros */}
          <div className="lg:px-8">
            <h3 className="font-serif text-lg font-semibold text-cream">Nosotros</h3>
            <p className="mt-4 text-sm leading-relaxed text-cream/70">
              {business.about}
            </p>
          </div>

          {/* Contacto */}
          <div className="lg:px-8">
            <h3 className="font-serif text-lg font-semibold text-cream">Contacto</h3>
            <ul className="mt-4 space-y-3 text-sm text-cream/80">
              <li>
                <a
                  href={`tel:${business.phoneDigits}`}
                  className="flex items-center gap-2 hover:text-cream"
                >
                  <Phone className="h-4 w-4 text-champagne-mist-300" />
                  {business.phone}
                </a>
              </li>
              <li>
                <a
                  href={`mailto:${business.email}`}
                  className="flex items-center gap-2 hover:text-cream"
                >
                  <Mail className="h-4 w-4 text-champagne-mist-300" />
                  {business.email}
                </a>
              </li>
            </ul>
            <p className="mt-5 text-sm font-medium text-cream/90">Redes</p>
            <div className="mt-2 flex items-center gap-4">
              <a
                href={business.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-cream/80 hover:text-cream"
                aria-label="Instagram de Comal de Casa"
              >
                <Instagram className="h-5 w-5 text-champagne-mist-300" />
                @{business.instagram}
              </a>
              <a
                href={messages.delivery}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-cream/80 hover:text-cream"
                aria-label="WhatsApp de Comal de Casa"
              >
                <svg
                  className="h-5 w-5 text-champagne-mist-300"
                  viewBox="0 0 24 24"
                  fill="currentColor"
                  aria-hidden="true"
                >
                  <path d="M17.47 14.38c-.3-.15-1.74-.86-2-.95-.27-.1-.46-.15-.66.15-.2.3-.76.95-.93 1.15-.17.2-.34.22-.64.07-.3-.15-1.25-.46-2.38-1.47-.88-.78-1.47-1.75-1.64-2.05-.17-.3-.02-.46.13-.61.13-.13.3-.34.44-.51.15-.17.2-.29.3-.49.1-.2.05-.37-.02-.52-.07-.15-.66-1.6-.9-2.18-.24-.57-.48-.49-.66-.5-.17 0-.37-.01-.56-.01-.2 0-.52.07-.79.37-.27.3-1.04 1.02-1.04 2.48 0 1.46 1.07 2.87 1.22 3.07.15.2 2.1 3.2 5.08 4.49.71.31 1.26.49 1.69.62.71.23 1.36.2 1.87.12.57-.08 1.74-.71 1.99-1.4.24-.69.24-1.28.17-1.4-.07-.12-.27-.2-.57-.34z" />
                  <path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2 22l5.25-1.38c1.45.79 3.08 1.21 4.79 1.21 5.46 0 9.91-4.45 9.91-9.91C22 6.45 17.5 2 12.04 2zm0 18.15c-1.52 0-3.01-.41-4.3-1.18l-.31-.18-3.12.82.83-3.04-.2-.31a8.2 8.2 0 0 1-1.26-4.35c0-4.54 3.7-8.23 8.24-8.23 2.2 0 4.27.86 5.82 2.42a8.18 8.18 0 0 1 2.41 5.82c0 4.54-3.7 8.23-8.24 8.23z" />
                </svg>
                WhatsApp
              </a>
            </div>
          </div>

          {/* Ubicación */}
          <div className="lg:pl-8">
            <h3 className="font-serif text-lg font-semibold text-cream">Ubicación</h3>
            <a
              href={business.mapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-4 block overflow-hidden rounded-[4px]"
            >
              <img
                src={business.mapsEmbed}
                alt="Vista aérea de la ubicación de Comal de Casa"
                width={500}
                height={300}
                className="h-32 w-full object-cover"
              />
            </a>
            <p className="mt-3 flex items-start gap-2 text-sm text-cream/80">
              <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-champagne-mist-300" />
              {business.address}
            </p>
            <ul className="mt-3 space-y-1 text-sm text-cream/70">
              {business.hours.map((h) => (
                <li key={h.day} className="flex items-start gap-2">
                  <Clock className="mt-0.5 h-4 w-4 shrink-0 text-champagne-mist-300" />
                  <span>
                    <span className="text-cream/90">{h.day}:</span> {h.time}
                  </span>
                </li>
              ))}
            </ul>
            <a
              href={business.mapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-4 inline-block text-sm text-rich-mahogany-200 underline underline-offset-[0.25em] hover:text-cream"
            >
              Cómo llegar
            </a>
          </div>
        </div>
      </div>
      <div className="border-t border-rich-mahogany-800 py-6">
        <p className="text-center text-xs text-cream/60">
          &copy; 2026 {business.name}. Todos los derechos reservados.
        </p>
      </div>
    </footer>
  );
}
