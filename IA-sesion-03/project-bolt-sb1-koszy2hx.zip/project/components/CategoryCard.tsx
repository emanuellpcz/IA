import Link from 'next/link';
import type { MenuCategory } from '@/lib/menu';

export function CategoryCard({ category }: { category: MenuCategory }) {
  return (
    <Link
      href={`/menu/${category.slug}`}
      className="group block focus-ring rounded-[4px]"
    >
      <div className="relative aspect-[4/5] overflow-hidden rounded-[4px]">
        <img
          src={category.cardImage}
          alt={category.cardAlt}
          width={640}
          height={800}
          className="h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-105 motion-reduce:transition-none"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-rich-mahogany-950/80 via-rich-mahogany-950/10 to-transparent" />
        <h3
          className="absolute bottom-4 left-4 font-serif font-semibold text-cream"
          style={{ fontSize: '1.5rem' }}
        >
          {category.name}
        </h3>
      </div>
      <p className="mt-3 text-sm leading-relaxed text-rich-mahogany-700/80">
        {category.cardText}
      </p>
      <span className="mt-2 inline-block text-sm font-medium text-rich-mahogany-600 underline underline-offset-[0.25em]">
        Ver categoría
      </span>
    </Link>
  );
}
