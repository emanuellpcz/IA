import { whatsappUrl, messages, business } from '@/lib/business';

interface WhatsAppButtonProps {
  variant: 'primary' | 'secondary' | 'text';
  label?: string;
  message?: 'delivery' | 'reserve' | 'club';
  href?: string;
  className?: string;
  size?: 'default' | 'lg';
}

const base =
  'inline-flex items-center justify-center font-sans font-semibold rounded-full transition-colors focus-ring select-none';

const variants = {
  primary:
    'bg-champagne-mist-400 text-rich-mahogany-950 hover:bg-champagne-mist-500',
  secondary:
    'border-[1.5px] border-cream text-cream hover:bg-cream/10 bg-transparent',
  text: 'text-rich-mahogany-600 underline underline-offset-[0.25em] hover:text-rich-mahogany-700',
};

const sizes = {
  default: 'h-11 px-6 text-sm',
  lg: 'h-14 px-8 text-base',
};

export function WhatsAppButton({
  variant,
  label,
  message,
  href,
  className = '',
  size = 'default',
}: WhatsAppButtonProps) {
  const url =
    href ??
    (message ? messages[message] : whatsappUrl(`Hola ${business.name},`));

  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className={`${base} ${variants[variant]} ${sizes[size]} ${className}`}
    >
      {label}
    </a>
  );
}
