'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useState, useEffect } from 'react';
import { ChevronDown, Menu, X } from 'lucide-react';
import { Logo } from '@/components/Logo';
import { WhatsAppButton } from '@/components/WhatsAppButton';
import { categories } from '@/lib/menu';
import { cn } from '@/lib/utils';

const navLinks = [
  { label: 'Inicio', href: '/' },
  { label: 'Nosotros', href: '/#nosotros' },
  { label: 'Contáctanos', href: '/#contacto' },
  { label: 'Membresía', href: '/membresia' },
  { label: 'Reservas', href: '/reservas' },
];

export function Header() {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [pathname]);

  const isActive = (href: string) => {
    if (href === '/') return pathname === '/';
    if (href.startsWith('/#')) return pathname === '/';
    if (href === '/membresia') return pathname === '/membresia';
    if (href === '/reservas') return pathname === '/reservas';
    return false;
  };

  const isMenuActive = pathname.startsWith('/menu');

  return (
    <header
      className={cn(
        'sticky top-0 z-50 bg-white transition-shadow',
        scrolled ? 'shadow-sm' : 'shadow-none'
      )}
    >
      <div className="border-b border-rich-mahogany-100">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
          {/* Logo */}
          <Link href="/" className="focus-ring rounded-[4px]" aria-label="Comal de Casa, inicio">
            <Logo variant="dark" />
          </Link>

          {/* Nav escritorio */}
          <nav className="hidden items-center gap-7 lg:flex" aria-label="Navegación principal">
            <Link
              href="/"
              className={cn(
                'relative py-1 text-sm font-medium text-rich-mahogany-950 transition-colors hover:text-rich-mahogany-600 focus-ring rounded',
                isActive('/') && 'text-rich-mahogany-700'
              )}
            >
              Inicio
              {isActive('/') && (
                <span className="absolute -bottom-px left-0 h-0.5 w-full bg-rich-mahogany-600" />
              )}
            </Link>

            {/* Menú desplegable */}
            <div
              className="relative"
              onMouseEnter={() => setMenuOpen(true)}
              onMouseLeave={() => setMenuOpen(false)}
            >
              <Link
                href="/#menu"
                className={cn(
                  'flex items-center gap-1 py-1 text-sm font-medium text-rich-mahogany-950 transition-colors hover:text-rich-mahogany-600 focus-ring rounded',
                  isMenuActive && 'text-rich-mahogany-700'
                )}
                aria-expanded={menuOpen}
              >
                Menú
                <ChevronDown
                  className={cn('h-4 w-4 transition-transform', menuOpen && 'rotate-180')}
                />
                {isMenuActive && (
                  <span className="absolute -bottom-px left-0 h-0.5 w-full bg-rich-mahogany-600" />
                )}
              </Link>
              {menuOpen && (
                <div className="absolute left-1/2 top-full z-50 w-64 -translate-x-1/2 pt-3">
                  <div className="overflow-hidden rounded-[4px] border border-rich-mahogany-100 bg-white py-2 shadow-lg">
                    {categories.map((cat) => (
                      <Link
                        key={cat.slug}
                        href={`/menu/${cat.slug}`}
                        className={cn(
                          'block px-4 py-2 text-sm text-rich-mahogany-950 transition-colors hover:bg-rich-mahogany-50 hover:text-rich-mahogany-700',
                          pathname === `/menu/${cat.slug}` &&
                            'bg-rich-mahogany-50 text-rich-mahogany-700'
                        )}
                      >
                        {cat.name}
                      </Link>
                    ))}
                    <div className="my-1 border-t border-rich-mahogany-100" />
                    <Link
                      href="/#menu"
                      className="block px-4 py-2 text-sm font-semibold text-rich-mahogany-700 transition-colors hover:bg-rich-mahogany-50"
                    >
                      Ver todas las categorías
                    </Link>
                  </div>
                </div>
              )}
            </div>

            {navLinks.slice(1).map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={cn(
                  'relative py-1 text-sm font-medium text-rich-mahogany-950 transition-colors hover:text-rich-mahogany-600 focus-ring rounded',
                  isActive(link.href) && 'text-rich-mahogany-700'
                )}
              >
                {link.label}
                {isActive(link.href) && (
                  <span className="absolute -bottom-px left-0 h-0.5 w-full bg-rich-mahogany-600" />
                )}
              </Link>
            ))}
          </nav>

          {/* Botón derecho */}
          <div className="hidden lg:block">
            <WhatsAppButton variant="primary" message="delivery" label="Pedir a domicilio" />
          </div>

          {/* Botón móvil */}
          <button
            className="rounded p-2 text-rich-mahogany-950 focus-ring lg:hidden"
            onClick={() => setMobileOpen((v) => !v)}
            aria-label={mobileOpen ? 'Cerrar menú' : 'Abrir menú'}
            aria-expanded={mobileOpen}
          >
            {mobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Panel móvil */}
      {mobileOpen && (
        <div className="border-b border-rich-mahogany-100 bg-white lg:hidden">
          <nav className="mx-auto max-w-7xl space-y-1 px-4 py-4 sm:px-6">
            <Link
              href="/"
              className="block rounded px-3 py-2 text-base font-medium text-rich-mahogany-950 hover:bg-rich-mahogany-50"
            >
              Inicio
            </Link>
            <details className="group">
              <summary className="flex cursor-pointer list-none items-center justify-between rounded px-3 py-2 text-base font-medium text-rich-mahogany-950 hover:bg-rich-mahogany-50">
                Menú
                <ChevronDown className="h-4 w-4 transition-transform group-open:rotate-180" />
              </summary>
              <div className="ml-3 border-l border-rich-mahogany-100 pl-3">
                {categories.map((cat) => (
                  <Link
                    key={cat.slug}
                    href={`/menu/${cat.slug}`}
                    className="block rounded px-3 py-2 text-sm text-rich-mahogany-700 hover:bg-rich-mahogany-50"
                  >
                    {cat.name}
                  </Link>
                ))}
                <Link
                  href="/#menu"
                  className="block rounded px-3 py-2 text-sm font-semibold text-rich-mahogany-700 hover:bg-rich-mahogany-50"
                >
                  Ver todas las categorías
                </Link>
              </div>
            </details>
            {navLinks.slice(1).map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="block rounded px-3 py-2 text-base font-medium text-rich-mahogany-950 hover:bg-rich-mahogany-50"
              >
                {link.label}
              </Link>
            ))}
            <div className="pt-3">
              <WhatsAppButton
                variant="primary"
                message="delivery"
                label="Pedir a domicilio"
                className="w-full"
              />
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
